###******************************************************************************
# Copyright (C) 2023 Harshal Sinkar
#
# Redistribution, modification or use of this software in source is allowed for
# peers to grade this assignment.
#
###*****************************************************************************


### This is a free access repository for the Coursera Specialization of Embedded
### Software Essentials to use in conjunction with the course1, the Introductio
### to Embedded Software and Development Environments.

### The repository has three files namely README.md stats.h stats.c

